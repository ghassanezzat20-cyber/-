const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(path.join(DATA_DIR, 'ltpolice.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS ranks (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('enlisted','officer')),
  level INTEGER NOT NULL UNIQUE,
  badge TEXT
);
CREATE TABLE IF NOT EXISTS teams (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  logo TEXT,
  mission TEXT,
  leader_id INTEGER,
  deputy_id INTEGER,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  military_no TEXT NOT NULL UNIQUE,
  rank_id INTEGER REFERENCES ranks(id),
  role TEXT NOT NULL DEFAULT 'officer' CHECK (role IN ('sysadmin','senior','trainer','officer')),
  team_id INTEGER REFERENCES teams(id) ON DELETE SET NULL,
  team_position TEXT,
  appointed_at TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','retired')),
  must_change_pw INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS activity_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  action TEXT NOT NULL,
  entity TEXT,
  entity_id INTEGER,
  details TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

// ترقية قواعد البيانات القديمة: إبطال الجلسات عند تغيير كلمة المرور
if (!db.prepare('PRAGMA table_info(users)').all().some(c => c.name === 'token_ver'))
  db.exec('ALTER TABLE users ADD COLUMN token_ver INTEGER NOT NULL DEFAULT 0');
db.exec('CREATE INDEX IF NOT EXISTS idx_users_team ON users(team_id); CREATE INDEX IF NOT EXISTS idx_activity_id ON activity_log(id)');

// الرتب العسكرية السعودية (بيانات مرجعية ثابتة وليست بيانات وهمية)
if (db.prepare('SELECT COUNT(*) c FROM ranks').get().c === 0) {
  const enlisted = ['جندي', 'جندي أول', 'عريف', 'وكيل رقيب', 'رقيب', 'رقيب أول', 'رئيس رقباء'];
  const officers = ['ملازم', 'ملازم أول', 'نقيب', 'رائد', 'مقدم', 'عقيد', 'عميد', 'لواء', 'فريق', 'فريق أول'];
  const ins = db.prepare('INSERT INTO ranks (name, category, level) VALUES (?,?,?)');
  db.transaction(() => {
    enlisted.forEach((n, i) => ins.run(n, 'enlisted', i + 1));
    officers.forEach((n, i) => ins.run(n, 'officer', enlisted.length + i + 1));
  })();
}

// ---------- الترقيات والنقاط والعقوبات ----------
const SEED = require('./seed.json');
db.exec(`
CREATE TABLE IF NOT EXISTS point_actions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL, name TEXT NOT NULL, points INTEGER NOT NULL, note TEXT,
  UNIQUE (category, name)
);
CREATE TABLE IF NOT EXISTS rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL CHECK (kind IN ('law','violation')), degree INTEGER, text TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('award','penalty','promotion')),
  title TEXT NOT NULL, delta INTEGER NOT NULL DEFAULT 0, degree INTEGER,
  rank_from INTEGER, rank_to INTEGER, note TEXT, by_user INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_records_user ON records(user_id);
`);
const rankCols = db.prepare('PRAGMA table_info(ranks)').all().map(c => c.name);
if (!rankCols.includes('points_required')) {
  db.exec('ALTER TABLE ranks ADD COLUMN points_required INTEGER; ALTER TABLE ranks ADD COLUMN description TEXT');
  const up = db.prepare('UPDATE ranks SET points_required=?, description=? WHERE name=?');
  for (const [n, v] of Object.entries(SEED.ranks)) up.run(v.points_required ?? null, v.description ?? null, n);
}
if (!db.prepare("SELECT 1 FROM ranks WHERE name='مستجد'").get())
  db.prepare("INSERT INTO ranks (name, category, level) VALUES ('مستجد','enlisted',0)").run();
if (db.prepare('SELECT COUNT(*) c FROM point_actions').get().c === 0) {
  const ins = db.prepare('INSERT INTO point_actions (category,name,points,note) VALUES (?,?,?,?)');
  db.transaction(() => SEED.actions.forEach(a => ins.run(...a)))();
}
if (db.prepare('SELECT COUNT(*) c FROM rules').get().c === 0) {
  const ins = db.prepare('INSERT INTO rules (kind,degree,text) VALUES (?,?,?)');
  db.transaction(() => {
    SEED.laws.forEach(t => ins.run('law', null, t));
    for (const [d, list] of Object.entries(SEED.violations)) list.forEach(t => ins.run('violation', Number(d), t));
  })();
}

module.exports = { db, DATA_DIR, DEGREES: SEED.degrees };
