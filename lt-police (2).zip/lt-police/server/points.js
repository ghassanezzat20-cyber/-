// نظام النقاط والترقيات والعقوبات
module.exports = ({ app, db, DEGREES, auth, need, wrap, bad, log, str, badgeUrl }) => {
  const staff = need('sysadmin', 'senior');
  const int = v => (/^-?\d+$/.test(String(v).trim()) ? parseInt(v, 10) : NaN);
  const pts = uid => db.prepare('SELECT COALESCE(SUM(delta),0) s FROM records WHERE user_id=?').get(uid).s;
  const ranksAsc = () => db.prepare('SELECT * FROM ranks ORDER BY level').all();
  const addRec = (r, by) => db.prepare(`INSERT INTO records (user_id,type,title,delta,degree,rank_from,rank_to,note,by_user) VALUES (?,?,?,?,?,?,?,?,?)`)
    .run(r.user_id, r.type, r.title, r.delta || 0, r.degree || null, r.rank_from || null, r.rank_to || null, r.note || '', by);
  const target = (req, res) => {
    const u = db.prepare('SELECT * FROM users WHERE id=?').get(Number(req.params.id || req.body.user_id));
    if (!u || u.status !== 'active') return bad(res, 'ضابط غير موجود أو غير نشط'), null;
    if (u.id === req.user.id) return bad(res, 'لا يمكنك تنفيذ هذا الإجراء على حسابك'), null;
    return u;
  };
  const rankPick = (req, res, u) => (req.user.role === 'senior' && u.role === 'sysadmin') ? (bad(res, 'لا تملك الصلاحية على مدير النظام', 403), false) : true;

  // رتبة: النقاط المطلوبة والوصف
  app.put('/api/ranks/:id', auth, need('sysadmin'), wrap((req, res) => {
    const r = db.prepare('SELECT * FROM ranks WHERE id=?').get(req.params.id);
    if (!r) return bad(res, 'الرتبة غير موجودة', 404);
    const raw = req.body.points_required, pr = raw === '' || raw == null ? null : int(raw);
    if (pr !== null && (!(pr >= 0) || pr > 1000000)) return bad(res, 'عدد النقاط غير صالح');
    db.prepare('UPDATE ranks SET points_required=?, description=? WHERE id=?').run(pr, str(req.body.description, 600) || null, r.id);
    log(req.user, 'تعديل متطلبات رتبة: ' + r.name, 'ranks', r.id);
    res.json({ ok: true });
  }));

  // جدول النقاط
  app.get('/api/points/actions', auth, wrap((req, res) => res.json(db.prepare('SELECT * FROM point_actions ORDER BY category, id').all())));
  const actIn = b => ({ category: str(b.category, 40), name: str(b.name, 120), points: int(b.points), note: str(b.note, 300) });
  const actOk = a => a.category && a.name && a.points >= 1 && a.points <= 100000;
  app.post('/api/points/actions', auth, need('sysadmin'), wrap((req, res) => {
    const a = actIn(req.body); if (!actOk(a)) return bad(res, 'التصنيف والاسم والنقاط (رقم موجب) مطلوبة');
    const r = db.prepare('INSERT INTO point_actions (category,name,points,note) VALUES (?,?,?,?)').run(a.category, a.name, a.points, a.note);
    log(req.user, 'إضافة عمل للنقاط: ' + a.name, 'point_actions', r.lastInsertRowid); res.json({ id: r.lastInsertRowid });
  }));
  app.put('/api/points/actions/:id', auth, need('sysadmin'), wrap((req, res) => {
    const a = actIn(req.body); if (!actOk(a)) return bad(res, 'التصنيف والاسم والنقاط (رقم موجب) مطلوبة');
    if (!db.prepare('UPDATE point_actions SET category=?,name=?,points=?,note=? WHERE id=?').run(a.category, a.name, a.points, a.note, req.params.id).changes) return bad(res, 'غير موجود', 404);
    log(req.user, 'تعديل عمل للنقاط: ' + a.name, 'point_actions', Number(req.params.id)); res.json({ ok: true });
  }));
  app.delete('/api/points/actions/:id', auth, need('sysadmin'), wrap((req, res) => {
    const a = db.prepare('SELECT * FROM point_actions WHERE id=?').get(req.params.id); if (!a) return bad(res, 'غير موجود', 404);
    db.prepare('DELETE FROM point_actions WHERE id=?').run(a.id); log(req.user, 'حذف عمل من النقاط: ' + a.name, 'point_actions', a.id); res.json({ ok: true });
  }));

  // القوانين والبنود ودرجات العقوبة
  app.get('/api/rules', auth, wrap((req, res) => {
    const all = db.prepare('SELECT * FROM rules ORDER BY id').all();
    res.json({
      laws: all.filter(r => r.kind === 'law'),
      degrees: Object.entries(DEGREES).map(([d, label]) => ({ degree: Number(d), label, items: all.filter(r => r.kind === 'violation' && r.degree === Number(d)) })),
    });
  }));
  app.post('/api/rules', auth, need('sysadmin'), wrap((req, res) => {
    const kind = req.body.kind === 'law' ? 'law' : 'violation', text = str(req.body.text, 200), degree = kind === 'law' ? null : int(req.body.degree);
    if (!text) return bad(res, 'النص مطلوب');
    if (kind === 'violation' && !DEGREES[degree]) return bad(res, 'درجة غير صالحة');
    const r = db.prepare('INSERT INTO rules (kind,degree,text) VALUES (?,?,?)').run(kind, degree, text);
    log(req.user, 'إضافة ' + (kind === 'law' ? 'قانون' : 'بند') + ': ' + text, 'rules', r.lastInsertRowid); res.json({ id: r.lastInsertRowid });
  }));
  app.delete('/api/rules/:id', auth, need('sysadmin'), wrap((req, res) => {
    const r = db.prepare('SELECT * FROM rules WHERE id=?').get(req.params.id); if (!r) return bad(res, 'غير موجود', 404);
    db.prepare('DELETE FROM rules WHERE id=?').run(r.id); log(req.user, 'حذف قانون/بند: ' + r.text, 'rules', r.id); res.json({ ok: true });
  }));

  // ملخص الاستحقاق
  app.get('/api/points/summary', auth, wrap((req, res) => {
    const rk = ranksAsc();
    const list = db.prepare(`SELECT u.id,u.full_name,u.rank_id,r.name rank_name,r.level rank_level,r.badge rank_badge FROM users u LEFT JOIN ranks r ON r.id=u.rank_id WHERE u.status='active'`).all().map(u => {
      const p = pts(u.id), next = rk.find(r => u.rank_level == null || r.level > u.rank_level);
      return { ...u, rank_badge: badgeUrl(u.rank_badge), points: p, next_name: next ? next.name : null, next_required: next ? next.points_required : null, eligible: !!(next && next.points_required != null && p >= next.points_required) };
    });
    res.json(list.sort((a, b) => (b.rank_level ?? -1) - (a.rank_level ?? -1) || b.points - a.points));
  }));

  app.get('/api/officers/:id/records', auth, wrap((req, res) => {
    const id = Number(req.params.id);
    if (id !== req.user.id && !['sysadmin', 'senior'].includes(req.user.role)) return bad(res, 'لا تملك الصلاحية لهذا الإجراء', 403);
    res.json({ points: pts(id), records: db.prepare(`SELECT c.*, b.full_name by_name, f.name rank_from_name, t.name rank_to_name FROM records c
      LEFT JOIN users b ON b.id=c.by_user LEFT JOIN ranks f ON f.id=c.rank_from LEFT JOIN ranks t ON t.id=c.rank_to WHERE c.user_id=? ORDER BY c.id DESC LIMIT 200`).all(id) });
  }));

  // منح نقاط
  app.post('/api/records', auth, staff, wrap((req, res) => {
    const u = target(req, res); if (!u) return;
    const note = str(req.body.note, 500); let title, delta;
    if (req.body.action_id) {
      const a = db.prepare('SELECT * FROM point_actions WHERE id=?').get(Number(req.body.action_id)); if (!a) return bad(res, 'العمل غير موجود');
      const q = int(req.body.qty || 1); if (!(q >= 1 && q <= 100)) return bad(res, 'العدد من 1 إلى 100');
      delta = a.points * q; title = a.name + (q > 1 ? ' ×' + q : '');
    } else {
      delta = int(req.body.points);
      if (!(delta >= 1 && delta <= 500)) return bad(res, 'النقاط التقديرية من 1 إلى 500');
      if (!note) return bad(res, 'اكتب سبب النقاط التقديرية');
      title = 'نقاط تقديرية';
    }
    addRec({ user_id: u.id, type: 'award', title, delta, note }, req.user.id);
    log(req.user, `منح ${delta} نقطة: ${u.full_name}`, 'users', u.id, title);
    res.json({ points: pts(u.id) });
  }));

  // عقوبة
  app.post('/api/penalties', auth, staff, wrap((req, res) => {
    const u = target(req, res); if (!u || !rankPick(req, res, u)) return;
    const degree = int(req.body.degree); if (!DEGREES[degree]) return bad(res, 'درجة غير صالحة');
    const title = str(req.body.title, 200), note = str(req.body.note, 500);
    if (!title) return bad(res, 'اكتب المخالفة');
    let delta = 0, rank_from = u.rank_id, rank_to = null;
    if (degree === 2 || degree === 3) {
      const cap = degree === 2 ? 50 : 100, d = int(req.body.deduct);
      if (!(d >= 1 && d <= cap)) return bad(res, `الخصم من 1 إلى ${cap} نقطة`);
      delta = -d;
    }
    if (degree === 4) {
      const n = int(req.body.demote || 1); if (n !== 1 && n !== 2) return bad(res, 'التنزيل رتبة أو رتبتان');
      const cur = db.prepare('SELECT * FROM ranks WHERE id=?').get(u.rank_id);
      const below = cur ? db.prepare('SELECT * FROM ranks WHERE level<? ORDER BY level DESC').all(cur.level) : [];
      if (!below.length) return bad(res, 'لا توجد رتبة أدنى');
      rank_to = below[Math.min(n, below.length) - 1].id;
      db.prepare('UPDATE users SET rank_id=? WHERE id=?').run(rank_to, u.id);
    }
    db.transaction(() => {
      if (degree === 1) {
        db.prepare("UPDATE users SET status='suspended' WHERE id=?").run(u.id);
        db.prepare('UPDATE teams SET leader_id=NULL WHERE leader_id=?').run(u.id);
        db.prepare('UPDATE teams SET deputy_id=NULL WHERE deputy_id=?').run(u.id);
      }
      addRec({ user_id: u.id, type: 'penalty', title, delta, degree, rank_from, rank_to, note }, req.user.id);
    })();
    log(req.user, `عقوبة (الدرجة ${degree} - ${DEGREES[degree]}): ${u.full_name}`, 'users', u.id, title);
    res.json({ points: pts(u.id) });
  }));

  // ترقية
  app.post('/api/officers/:id/promote', auth, staff, wrap((req, res) => {
    const u = target(req, res); if (!u || !rankPick(req, res, u)) return;
    const cur = db.prepare('SELECT * FROM ranks WHERE id=?').get(u.rank_id);
    const next = ranksAsc().find(r => !cur || r.level > cur.level);
    if (!next) return bad(res, 'الضابط في أعلى رتبة');
    const ok = next.points_required != null && pts(u.id) >= next.points_required;
    const force = req.body.force === true && req.user.role === 'sysadmin';
    if (!ok && !force) return bad(res, 'لم يبلغ النقاط المطلوبة للرتبة التالية');
    db.transaction(() => {
      db.prepare('UPDATE users SET rank_id=? WHERE id=?').run(next.id, u.id);
      addRec({ user_id: u.id, type: 'promotion', title: 'ترقية إلى ' + next.name + (ok ? '' : ' (استثنائية)'), rank_from: u.rank_id, rank_to: next.id, note: str(req.body.note, 500) }, req.user.id);
    })();
    log(req.user, `ترقية ${u.full_name} إلى ${next.name}`, 'users', u.id);
    res.json({ rank: next.name });
  }));
};
