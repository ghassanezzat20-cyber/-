const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { db, DATA_DIR, DEGREES } = require('./db');

const app = express();
app.disable('x-powered-by');
// خلف Nginx أو منصة استضافة: اضبط TRUST_PROXY=1 ليُقرأ عنوان IP الحقيقي
if (process.env.TRUST_PROXY) app.set('trust proxy', Number(process.env.TRUST_PROXY) || process.env.TRUST_PROXY);
app.use(express.json({ limit: '3mb' }));
app.use((req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin',
    'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
  });
  if (req.path.startsWith('/api/')) res.set('Cache-Control', 'no-store');
  next();
});

// ---------- الإعدادات والأسرار ----------
const secretFile = path.join(DATA_DIR, 'jwt.secret');
let SECRET = process.env.JWT_SECRET;
if (!SECRET) {
  if (!fs.existsSync(secretFile)) fs.writeFileSync(secretFile, crypto.randomBytes(48).toString('hex'), { mode: 0o600 });
  SECRET = fs.readFileSync(secretFile, 'utf8');
}
const UPLOADS = path.join(DATA_DIR, 'uploads');
['badges', 'logos'].forEach(d => fs.mkdirSync(path.join(UPLOADS, d), { recursive: true }));

const ROLES = ['sysadmin', 'senior', 'trainer', 'officer'];
const STATUSES = ['active', 'suspended', 'retired'];

// ---------- أدوات مساعدة ----------
const str = (v, max = 200) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
const bad = (res, m, c = 400) => res.status(c).json({ error: m });
const log = (u, action, entity, id, details) =>
  db.prepare('INSERT INTO activity_log (user_id, action, entity, entity_id, details) VALUES (?,?,?,?,?)')
    .run(u ? u.id : null, action, entity || null, id || null, details || '');
const wrap = fn => (req, res) => {
  try { fn(req, res); } catch (e) {
    if (String(e.message).includes('UNIQUE')) return bad(res, 'القيمة مستخدمة مسبقاً (اسم المستخدم أو الرقم العسكري أو اسم الفرقة)', 409);
    console.error(e); bad(res, 'خطأ في الخادم', 500);
  }
};

function saveImage(dataUrl, sub) {
  const m = /^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl || '');
  if (!m) return null;
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > 1.5 * 1024 * 1024) return null;
  const name = crypto.randomBytes(10).toString('hex') + '.' + (m[1] === 'jpeg' ? 'jpg' : m[1]);
  fs.writeFileSync(path.join(UPLOADS, sub, name), buf);
  return name;
}
const rmFile = (sub, name) => { if (name) fs.rmSync(path.join(UPLOADS, sub, path.basename(name)), { force: true }); };

// ---------- المصادقة ----------
function auth(req, res, next) {
  try {
    const p = jwt.verify((req.headers.authorization || '').slice(7), SECRET);
    const u = db.prepare('SELECT id, username, full_name, role, status, must_change_pw, token_ver FROM users WHERE id=?').get(p.id);
    if (!u || u.status !== 'active' || u.token_ver !== (p.v || 0)) throw new Error('x');
    if (u.must_change_pw && !['/api/me', '/api/change-password'].includes(req.originalUrl.split('?')[0]))
      return bad(res, 'يجب تغيير كلمة المرور أولاً', 403);
    delete u.token_ver; req.user = u; next();
  } catch { bad(res, 'يلزم تسجيل الدخول', 401); }
}
const need = (...roles) => (req, res, next) => roles.includes(req.user.role) ? next() : bad(res, 'لا تملك الصلاحية لهذا الإجراء', 403);

const attempts = new Map(); // حماية بسيطة من تخمين كلمات المرور
setInterval(() => {
  const now = Date.now();
  for (const [k, a] of attempts) if (!a.some(t => now - t < 10 * 60 * 1000)) attempts.delete(k);
}, 10 * 60 * 1000).unref();
const DUMMY_HASH = bcrypt.hashSync('dummy-password-for-timing', 12);
function throttled(key) {
  const now = Date.now();
  const a = (attempts.get(key) || []).filter(t => now - t < 10 * 60 * 1000);
  attempts.set(key, a);
  return a.length >= 5;
}

app.get('/api/setup-status', wrap((req, res) => {
  res.json({ needed: db.prepare('SELECT COUNT(*) c FROM users').get().c === 0 });
}));

app.post('/api/setup', wrap((req, res) => {
  if (db.prepare('SELECT COUNT(*) c FROM users').get().c > 0) return bad(res, 'تم إعداد النظام مسبقاً', 403);
  const { username, password, full_name, military_no } = req.body;
  if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(username || '')) return bad(res, 'اسم المستخدم: 3-32 حرفاً إنجليزياً أو أرقاماً');
  if (str(password, 200).length < 8) return bad(res, 'كلمة المرور 8 أحرف على الأقل');
  if (!str(full_name) || !str(military_no, 30)) return bad(res, 'الاسم والرقم العسكري مطلوبان');
  const top = db.prepare('SELECT id FROM ranks ORDER BY level DESC LIMIT 1').get();
  const r = db.prepare("INSERT INTO users (username,password_hash,full_name,military_no,rank_id,role,appointed_at) VALUES (?,?,?,?,?,'sysadmin',date('now'))")
    .run(username, bcrypt.hashSync(password, 12), str(full_name), str(military_no, 30), top.id);
  log({ id: r.lastInsertRowid }, 'إعداد النظام وإنشاء مدير النظام', 'users', r.lastInsertRowid);
  res.json({ ok: true });
}));

app.post('/api/login', wrap((req, res) => {
  const username = str(req.body.username, 32), password = str(req.body.password, 200);
  const key = req.ip + '|' + username.toLowerCase();
  if (throttled(key)) return bad(res, 'محاولات كثيرة، حاول بعد 10 دقائق', 429);
  const u = db.prepare('SELECT * FROM users WHERE username=?').get(username);
  const okPw = bcrypt.compareSync(password, u ? u.password_hash : DUMMY_HASH);
  if (!u || !okPw || u.status !== 'active') {
    attempts.get(key).push(Date.now());
    return bad(res, 'بيانات الدخول غير صحيحة أو الحساب غير نشط', 401);
  }
  attempts.delete(key);
  log(u, 'تسجيل دخول', 'users', u.id);
  res.json({ token: jwt.sign({ id: u.id, v: u.token_ver }, SECRET, { expiresIn: '8h' }) });
}));

app.get('/api/me', auth, wrap((req, res) => res.json(req.user)));

app.post('/api/change-password', auth, wrap((req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  const next = str(req.body.next, 200);
  if (!bcrypt.compareSync(str(req.body.current, 200), u.password_hash)) return bad(res, 'كلمة المرور الحالية غير صحيحة');
  if (next.length < 8) return bad(res, 'كلمة المرور الجديدة 8 أحرف على الأقل');
  if (next === str(req.body.current, 200)) return bad(res, 'اختر كلمة مرور مختلفة عن الحالية');
  db.prepare('UPDATE users SET password_hash=?, must_change_pw=0, token_ver=token_ver+1 WHERE id=?').run(bcrypt.hashSync(next, 12), u.id);
  log(req.user, 'تغيير كلمة المرور', 'users', u.id);
  // جلسة جديدة لهذا الجهاز، وتُبطل بقية الجلسات القديمة
  res.json({ ok: true, token: jwt.sign({ id: u.id, v: u.token_ver + 1 }, SECRET, { expiresIn: '8h' }) });
}));

// ---------- الرتب والشارات ----------
const badgeUrl = b => (b ? '/uploads/badges/' + b : null);
app.get('/api/ranks', auth, wrap((req, res) => {
  res.json(db.prepare('SELECT * FROM ranks ORDER BY level').all().map(r => ({ ...r, badge: badgeUrl(r.badge) })));
}));
app.put('/api/ranks/:id/badge', auth, need('sysadmin'), wrap((req, res) => {
  const r = db.prepare('SELECT * FROM ranks WHERE id=?').get(req.params.id);
  if (!r) return bad(res, 'الرتبة غير موجودة', 404);
  const name = saveImage(req.body.image, 'badges');
  if (!name) return bad(res, 'صورة غير صالحة (PNG أو JPG أو WebP حتى 1.5MB)');
  rmFile('badges', r.badge);
  db.prepare('UPDATE ranks SET badge=? WHERE id=?').run(name, r.id);
  log(req.user, 'تغيير شارة رتبة: ' + r.name, 'ranks', r.id);
  res.json({ badge: badgeUrl(name) });
}));
app.delete('/api/ranks/:id/badge', auth, need('sysadmin'), wrap((req, res) => {
  const r = db.prepare('SELECT * FROM ranks WHERE id=?').get(req.params.id);
  if (!r) return bad(res, 'الرتبة غير موجودة', 404);
  rmFile('badges', r.badge);
  db.prepare('UPDATE ranks SET badge=NULL WHERE id=?').run(r.id);
  log(req.user, 'حذف شارة رتبة: ' + r.name, 'ranks', r.id);
  res.json({ ok: true });
}));

// ---------- الضباط ----------
const OFFICER_SQL = `SELECT u.id,u.username,u.full_name,u.military_no,u.rank_id,u.role,u.team_id,u.team_position,
  u.appointed_at,u.status,u.created_at,r.name rank_name,r.level rank_level,r.badge rank_badge,t.name team_name
  FROM users u LEFT JOIN ranks r ON r.id=u.rank_id LEFT JOIN teams t ON t.id=u.team_id`;
const fmtOfficer = (o, viewer) => {
  if (!o) return o;
  const r = { ...o, rank_badge: badgeUrl(o.rank_badge) };
  if (!viewer || viewer.role !== 'sysadmin') delete r.username; // اسم الدخول للمدير فقط
  return r;
};

function syncPosition(uid) {
  const u = db.prepare('SELECT team_id, team_position FROM users WHERE id=?').get(uid);
  if (!u) return;
  let pos = u.team_position;
  if (!u.team_id) pos = null;
  else {
    const t = db.prepare('SELECT leader_id, deputy_id FROM teams WHERE id=?').get(u.team_id);
    if (t.leader_id === uid) pos = 'قائد الفرقة';
    else if (t.deputy_id === uid) pos = 'نائب القائد';
    else if (!pos || pos === 'قائد الفرقة' || pos === 'نائب القائد') pos = 'عضو';
  }
  db.prepare('UPDATE users SET team_position=? WHERE id=?').run(pos, uid);
}

function officerInput(b, creating) {
  const o = {
    full_name: str(b.full_name), military_no: str(b.military_no, 30),
    rank_id: b.rank_id ? Number(b.rank_id) : null, role: b.role,
    team_id: b.team_id ? Number(b.team_id) : null, team_position: str(b.team_position, 60) || null,
    appointed_at: str(b.appointed_at, 10) || null, status: b.status || 'active',
  };
  if ((b.rank_id && !Number.isInteger(o.rank_id)) || (b.team_id && !Number.isInteger(o.team_id))) return { err: 'قيمة غير صالحة' };
  if (o.appointed_at && !/^\d{4}-\d{2}-\d{2}$/.test(o.appointed_at)) return { err: 'تاريخ التعيين غير صالح' };
  if (creating) o.username = str(b.username, 32);
  if (!o.full_name || !o.military_no) return { err: 'الاسم والرقم العسكري مطلوبان' };
  if (creating && !/^[a-zA-Z0-9_.-]{3,32}$/.test(o.username)) return { err: 'اسم المستخدم: 3-32 حرفاً إنجليزياً أو أرقاماً' };
  if (!ROLES.includes(o.role)) return { err: 'دور غير صالح' };
  if (!STATUSES.includes(o.status)) return { err: 'حالة غير صالحة' };
  if (o.rank_id && !db.prepare('SELECT 1 FROM ranks WHERE id=?').get(o.rank_id)) return { err: 'رتبة غير موجودة' };
  if (o.team_id && !db.prepare('SELECT 1 FROM teams WHERE id=?').get(o.team_id)) return { err: 'فرقة غير موجودة' };
  return { o };
}

app.get('/api/officers', auth, wrap((req, res) => {
  res.json(db.prepare(OFFICER_SQL + ' ORDER BY r.level DESC, u.full_name').all().map(o => fmtOfficer(o, req.user)));
}));
app.get('/api/officers/:id', auth, wrap((req, res) => {
  const o = db.prepare(OFFICER_SQL + ' WHERE u.id=?').get(req.params.id);
  o ? res.json(fmtOfficer(o, req.user)) : bad(res, 'غير موجود', 404);
}));

app.post('/api/officers', auth, need('sysadmin'), wrap((req, res) => {
  const { o, err } = officerInput(req.body, true);
  if (err) return bad(res, err);
  const pw = str(req.body.password, 200);
  if (pw.length < 8) return bad(res, 'كلمة المرور 8 أحرف على الأقل');
  const r = db.prepare(`INSERT INTO users (username,password_hash,full_name,military_no,rank_id,role,team_id,team_position,appointed_at,status)
    VALUES (?,?,?,?,?,?,?,?,?,?)`).run(o.username, bcrypt.hashSync(pw, 12), o.full_name, o.military_no, o.rank_id, o.role, o.team_id, o.team_position, o.appointed_at, o.status);
  syncPosition(r.lastInsertRowid);
  log(req.user, 'إضافة ضابط: ' + o.full_name, 'users', r.lastInsertRowid);
  res.json({ id: r.lastInsertRowid });
}));

app.put('/api/officers/:id', auth, need('sysadmin'), wrap((req, res) => {
  const id = Number(req.params.id);
  const cur = db.prepare('SELECT * FROM users WHERE id=?').get(id);
  if (!cur) return bad(res, 'غير موجود', 404);
  const { o, err } = officerInput(req.body, false);
  if (err) return bad(res, err);
  const lastAdmin = db.prepare("SELECT COUNT(*) c FROM users WHERE role='sysadmin' AND status='active'").get().c;
  if (cur.role === 'sysadmin' && lastAdmin <= 1 && (o.role !== 'sysadmin' || o.status !== 'active'))
    return bad(res, 'لا يمكن تعطيل آخر مدير نظام');
  db.prepare(`UPDATE users SET full_name=?,military_no=?,rank_id=?,role=?,team_id=?,team_position=?,appointed_at=?,status=? WHERE id=?`)
    .run(o.full_name, o.military_no, o.rank_id, o.role, o.team_id, o.team_position, o.appointed_at, o.status, id);
  db.prepare('UPDATE teams SET leader_id=NULL WHERE leader_id=? AND id IS NOT ?').run(id, o.team_id);
  db.prepare('UPDATE teams SET deputy_id=NULL WHERE deputy_id=? AND id IS NOT ?').run(id, o.team_id);
  if (o.status !== 'active') {
    db.prepare('UPDATE teams SET leader_id=NULL WHERE leader_id=?').run(id);
    db.prepare('UPDATE teams SET deputy_id=NULL WHERE deputy_id=?').run(id);
  }
  syncPosition(id);
  const changes = [];
  if (cur.rank_id !== o.rank_id) changes.push('الرتبة');
  if (cur.team_id !== o.team_id) changes.push('الفرقة');
  if (cur.role !== o.role) changes.push('الدور');
  if (cur.status !== o.status) changes.push('الحالة');
  log(req.user, 'تعديل ضابط: ' + o.full_name, 'users', id, changes.length ? 'تغيّر: ' + changes.join('، ') : '');
  res.json({ ok: true });
}));

app.post('/api/officers/:id/reset-password', auth, need('sysadmin'), wrap((req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(req.params.id);
  if (!u) return bad(res, 'غير موجود', 404);
  const temp = crypto.randomBytes(8).toString('base64url');
  db.prepare('UPDATE users SET password_hash=?, must_change_pw=1, token_ver=token_ver+1 WHERE id=?').run(bcrypt.hashSync(temp, 12), u.id);
  log(req.user, 'إعادة تعيين كلمة مرور: ' + u.full_name, 'users', u.id);
  res.json({ temp_password: temp });
}));

app.delete('/api/officers/:id', auth, need('sysadmin'), wrap((req, res) => {
  const id = Number(req.params.id);
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(id);
  if (!u) return bad(res, 'غير موجود', 404);
  if (id === req.user.id) return bad(res, 'لا يمكنك حذف حسابك');
  db.prepare('UPDATE teams SET leader_id=NULL WHERE leader_id=?').run(id);
  db.prepare('UPDATE teams SET deputy_id=NULL WHERE deputy_id=?').run(id);
  db.prepare('DELETE FROM users WHERE id=?').run(id);
  log(req.user, 'حذف ضابط: ' + u.full_name, 'users', id);
  res.json({ ok: true });
}));

// ---------- الفرق ----------
const TEAM_SQL = `SELECT t.*, l.full_name leader_name, d.full_name deputy_name,
  (SELECT COUNT(*) FROM users m WHERE m.team_id=t.id) members_count
  FROM teams t LEFT JOIN users l ON l.id=t.leader_id LEFT JOIN users d ON d.id=t.deputy_id`;
const fmtTeam = t => t && ({ ...t, logo: t.logo ? '/uploads/logos/' + t.logo : null });

function applyTeamRoles(teamId, leaderId, deputyId) {
  const old = db.prepare('SELECT leader_id, deputy_id FROM teams WHERE id=?').get(teamId);
  // الضابط يقود فرقة واحدة فقط: أزله من أي فرقة أخرى كان قائداً أو نائباً فيها
  [leaderId, deputyId].filter(Boolean).forEach(uid => {
    db.prepare('UPDATE teams SET leader_id=NULL WHERE id!=? AND leader_id=?').run(teamId, uid);
    db.prepare('UPDATE teams SET deputy_id=NULL WHERE id!=? AND deputy_id=?').run(teamId, uid);
  });
  db.prepare('UPDATE teams SET leader_id=?, deputy_id=? WHERE id=?').run(leaderId, deputyId, teamId);
  [leaderId, deputyId].filter(Boolean).forEach(uid => db.prepare('UPDATE users SET team_id=? WHERE id=?').run(teamId, uid));
  [old.leader_id, old.deputy_id, leaderId, deputyId].filter(Boolean).forEach(syncPosition);
}
function teamInput(b) {
  const t = { name: str(b.name, 80), mission: str(b.mission, 1000), leader_id: b.leader_id ? Number(b.leader_id) : null, deputy_id: b.deputy_id ? Number(b.deputy_id) : null };
  if (!t.name) return { err: 'اسم الفرقة مطلوب' };
  if (t.leader_id && t.leader_id === t.deputy_id) return { err: 'القائد والنائب يجب أن يكونا شخصين مختلفين' };
  for (const id of [t.leader_id, t.deputy_id]) if (id && !db.prepare("SELECT 1 FROM users WHERE id=? AND status='active'").get(id)) return { err: 'ضابط غير موجود أو غير نشط' };
  return { t };
}

app.get('/api/teams', auth, wrap((req, res) => res.json(db.prepare(TEAM_SQL + ' ORDER BY t.name').all().map(fmtTeam))));
app.get('/api/teams/:id', auth, wrap((req, res) => {
  const t = db.prepare(TEAM_SQL + ' WHERE t.id=?').get(req.params.id);
  if (!t) return bad(res, 'غير موجودة', 404);
  const members = db.prepare(OFFICER_SQL + ' WHERE u.team_id=? ORDER BY r.level DESC').all(t.id).map(o => fmtOfficer(o, req.user));
  res.json({ ...fmtTeam(t), members });
}));

app.post('/api/teams', auth, need('sysadmin'), wrap((req, res) => {
  const { t, err } = teamInput(req.body);
  if (err) return bad(res, err);
  const logo = req.body.logo ? saveImage(req.body.logo, 'logos') : null;
  if (req.body.logo && !logo) return bad(res, 'شعار غير صالح (PNG أو JPG أو WebP حتى 1.5MB)');
  const r = db.prepare('INSERT INTO teams (name, mission, logo) VALUES (?,?,?)').run(t.name, t.mission, logo);
  applyTeamRoles(r.lastInsertRowid, t.leader_id, t.deputy_id);
  log(req.user, 'إنشاء فرقة: ' + t.name, 'teams', r.lastInsertRowid);
  res.json({ id: r.lastInsertRowid });
}));

app.put('/api/teams/:id', auth, need('sysadmin'), wrap((req, res) => {
  const id = Number(req.params.id);
  const cur = db.prepare('SELECT * FROM teams WHERE id=?').get(id);
  if (!cur) return bad(res, 'غير موجودة', 404);
  const { t, err } = teamInput(req.body);
  if (err) return bad(res, err);
  let logo = cur.logo;
  if (req.body.logo) {
    const n = saveImage(req.body.logo, 'logos');
    if (!n) return bad(res, 'شعار غير صالح (PNG أو JPG أو WebP حتى 1.5MB)');
    rmFile('logos', cur.logo); logo = n;
  }
  db.prepare('UPDATE teams SET name=?, mission=?, logo=? WHERE id=?').run(t.name, t.mission, logo, id);
  applyTeamRoles(id, t.leader_id, t.deputy_id);
  log(req.user, 'تعديل فرقة: ' + t.name, 'teams', id);
  res.json({ ok: true });
}));

app.post('/api/teams/:id/status', auth, need('sysadmin'), wrap((req, res) => {
  const status = req.body.status;
  if (!['active', 'suspended'].includes(status)) return bad(res, 'حالة غير صالحة');
  const t = db.prepare('SELECT * FROM teams WHERE id=?').get(req.params.id);
  if (!t) return bad(res, 'غير موجودة', 404);
  db.prepare('UPDATE teams SET status=? WHERE id=?').run(status, t.id);
  log(req.user, (status === 'active' ? 'إعادة تفعيل' : 'إيقاف') + ' فرقة: ' + t.name, 'teams', t.id);
  res.json({ ok: true });
}));

app.delete('/api/teams/:id', auth, need('sysadmin'), wrap((req, res) => {
  const t = db.prepare('SELECT * FROM teams WHERE id=?').get(req.params.id);
  if (!t) return bad(res, 'غير موجودة', 404);
  db.prepare('UPDATE users SET team_position=NULL WHERE team_id=?').run(t.id);
  db.prepare('DELETE FROM teams WHERE id=?').run(t.id);
  rmFile('logos', t.logo);
  log(req.user, 'حذف فرقة: ' + t.name, 'teams', t.id);
  res.json({ ok: true });
}));

// ---------- لوحة التحكم وسجل النشاطات ----------
const ACT_SQL = `SELECT a.id,a.action,a.details,a.created_at,u.full_name user_name FROM activity_log a LEFT JOIN users u ON u.id=a.user_id`;
app.get('/api/dashboard', auth, wrap((req, res) => {
  const c = sql => db.prepare(sql).get().c;
  const d = {
    officers: c("SELECT COUNT(*) c FROM users WHERE status='active'"),
    suspended: c("SELECT COUNT(*) c FROM users WHERE status!='active'"),
    teams: c('SELECT COUNT(*) c FROM teams'),
    active_teams: c("SELECT COUNT(*) c FROM teams WHERE status='active'"),
  };
  if (['sysadmin', 'senior'].includes(req.user.role)) d.activity = db.prepare(ACT_SQL + ' ORDER BY a.id DESC LIMIT 10').all();
  res.json(d);
}));
app.get('/api/activity', auth, need('sysadmin', 'senior'), wrap((req, res) => {
  res.json(db.prepare(ACT_SQL + ' ORDER BY a.id DESC LIMIT 300').all());
}));

require('./points')({ app, db, DEGREES, auth, need, wrap, bad, log, str, badgeUrl });

// ---------- الملفات الثابتة ----------
app.use('/uploads', express.static(UPLOADS, { index: false, dotfiles: 'deny' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

// ---------- معالجة الأخطاء ----------
app.use('/api', (req, res) => bad(res, 'المسار غير موجود', 404));
app.use((err, req, res, next) => {
  if (err.type === 'entity.too.large') return bad(res, 'الحجم كبير جداً', 413);
  if (err.type === 'entity.parse.failed') return bad(res, 'طلب غير صالح');
  console.error(err); bad(res, 'خطأ في الخادم', 500);
});

const PORT = process.env.PORT || 3000;
const server = app.listen(PORT, () => console.log('LT POLICE يعمل على: http://localhost:' + PORT));
const stop = () => server.close(() => { db.close(); process.exit(0); });
process.on('SIGTERM', stop); process.on('SIGINT', stop);
