const path = require('path');
const fs = require('fs');
const { db, DATA_DIR } = require('../server/db');
const dir = path.join(DATA_DIR, 'backups');
fs.mkdirSync(dir, { recursive: true });
const file = path.join(dir, 'ltpolice-' + new Date().toISOString().replace(/[:.]/g, '-') + '.db');
db.backup(file).then(() => { console.log('تم إنشاء النسخة الاحتياطية:', file); process.exit(0); })
  .catch(e => { console.error(e); process.exit(1); });
