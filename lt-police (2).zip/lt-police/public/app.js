const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let token = localStorage.getItem('ltp_token'), me = null, ranks = [];
const ROLE = { sysadmin: 'مدير النظام', senior: 'الإدارة العليا', trainer: 'مدرب', officer: 'ضابط' };
const STAT = { active: 'نشط', suspended: 'موقوف / مفصول', retired: 'متقاعد' };

function toast(m, err) { const t = $('#toast'); t.textContent = m; t.className = err ? 'e' : ''; t.style.display = 'block'; setTimeout(() => t.style.display = 'none', 3200); }
async function api(path, o = {}) {
  const r = await fetch('/api' + path, { method: o.method || 'GET', headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: o.body ? JSON.stringify(o.body) : undefined });
  let d = {}; try { d = await r.json(); } catch {}
  if (r.status === 401 && token && path !== '/login') logout();
  if (!r.ok) throw new Error(d.error || 'حدث خطأ');
  return d;
}
function logout() { localStorage.removeItem('ltp_token'); token = null; me = null; boot(); }
const fmtDate = s => s ? new Date(s.includes('T') ? s : s.replace(' ', 'T') + 'Z').toLocaleString('ar-SA') : '';
const badge = (url, lvl) => url ? `<img class="bd" src="${esc(url)}" alt="">` : `<span class="bd">${esc(lvl ?? '')}</span>`;
const tag = s => `<span class="tag ${esc(s)}">${esc(STAT[s] || s)}</span>`;

// ---------- نافذة نموذج عامة ----------
function formDialog(title, fields, vals, onSubmit) {
  const d = document.createElement('dialog');
  const input = f => {
    const v = vals[f.k] ?? '';
    if (f.type === 'select') return `<select name="${f.k}">${f.options.map(o => `<option value="${esc(o[0])}" ${String(v) === String(o[0]) ? 'selected' : ''}>${esc(o[1])}</option>`).join('')}</select>`;
    if (f.type === 'textarea') return `<textarea name="${f.k}" rows="3">${esc(v)}</textarea>`;
    if (f.type === 'image') return `<input type="file" name="${f.k}" accept="image/png,image/jpeg,image/webp">`;
    return `<input name="${f.k}" type="${f.type || 'text'}" value="${f.type === 'password' ? '' : esc(v)}" ${f.required ? 'required' : ''} ${f.type === 'password' ? 'autocomplete="new-password"' : ''}>`;
  };
  d.innerHTML = `<form class="f"><h3>${esc(title)}</h3>${fields.map(f => `<label>${esc(f.label)}${input(f)}</label>`).join('')}<p class="err"></p><div class="row"><button class="btn">حفظ</button><button type="button" class="btn ghost" data-x>إلغاء</button></div></form>`;
  document.body.appendChild(d); d.showModal();
  const close = () => { if (d.open) d.close(); d.remove(); };
  d.addEventListener('close', () => d.remove());
  d.querySelector('[data-x]').onclick = close;
  d.querySelector('form').onsubmit = async e => {
    e.preventDefault();
    const btn = d.querySelector('.btn'); if (btn.disabled) return; btn.disabled = true;
    const data = {};
    for (const f of fields) {
      const el = d.querySelector(`[name="${f.k}"]`);
      if (f.type === 'image') {
        const file = el.files[0];
        if (file) data[f.k] = await new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(file); });
      } else data[f.k] = el.value;
    }
    try { await onSubmit(data); close(); } catch (er) { d.querySelector('.err').textContent = er.message; btn.disabled = false; }
  };
}
function membersDialog(t) {
  const d = document.createElement('dialog');
  d.innerHTML = `<h3>أعضاء ${esc(t.name)}</h3><div class="tw"><table><tr><th>الرتبة</th><th>الاسم</th><th>المنصب</th></tr>${t.members.map(m => `<tr><td>${badge(m.rank_badge, m.rank_level)}${esc(m.rank_name || '—')}</td><td>${esc(m.full_name)}</td><td>${esc(m.team_position || '—')}</td></tr>`).join('') || '<tr><td colspan="3">لا يوجد أعضاء</td></tr>'}</table></div><div class="row"><button class="btn ghost" data-x>إغلاق</button></div>`;
  document.body.appendChild(d); d.showModal();
  d.addEventListener('close', () => d.remove());
  d.querySelector('[data-x]').onclick = () => d.close();
}
const confirmDo = (msg, fn) => { if (confirm(msg)) fn().catch(e => toast(e.message, 1)); };

// ---------- الدخول ----------
async function authView() {
  const setup = (await api('/setup-status')).needed;
  $('#app').innerHTML = `<div class="auth"><img src="logo.svg" alt=""><h2>LT POLICE</h2><p style="color:var(--mute)">${setup ? 'الإعداد الأولي: إنشاء حساب مدير النظام' : 'نظام إدارة الشرطة الإلكتروني'}</p>
  <form class="f card" id="af">${setup ? '<label>الاسم الكامل<input name="full_name" required></label><label>الرقم العسكري<input name="military_no" required></label>' : ''}
  <label>اسم المستخدم<input name="username" required autocomplete="username"></label><label>كلمة المرور<input name="password" type="password" required autocomplete="${setup ? 'new-password' : 'current-password'}"></label>
  <p class="err"></p><button class="btn" style="width:100%">${setup ? 'إنشاء الحساب' : 'تسجيل الدخول'}</button></form></div>`;
  $('#af').onsubmit = async e => {
    e.preventDefault();
    const b = Object.fromEntries(new FormData(e.target));
    try {
      if (setup) await api('/setup', { method: 'POST', body: b });
      const r = await api('/login', { method: 'POST', body: { username: b.username, password: b.password } });
      token = r.token; localStorage.setItem('ltp_token', token); boot();
    } catch (er) { $('.err').textContent = er.message; }
  };
}
function pwDialog(forced) {
  formDialog(forced ? 'يجب تغيير كلمة المرور المؤقتة' : 'تغيير كلمة المرور',
    [{ k: 'current', label: 'كلمة المرور الحالية', type: 'password', required: 1 }, { k: 'next', label: 'كلمة المرور الجديدة (8 أحرف على الأقل)', type: 'password', required: 1 }],
    {}, async d => { const r = await api('/change-password', { method: 'POST', body: d }); token = r.token; localStorage.setItem('ltp_token', token); toast('تم تغيير كلمة المرور'); if (forced) boot(); });
}

// ---------- الهيكل العام ----------
async function boot() {
  if (!token) return authView();
  try { me = await api('/me'); } catch { return authView(); }
  if (me.must_change_pw) { $('#app').innerHTML = ''; return pwDialog(true); }
  ranks = await api('/ranks');
  const adm = ['sysadmin', 'senior'].includes(me.role);
  const items = [['dashboard', 'لوحة التحكم', '📊'], ['officers', 'الضباط', '👮'], ['teams', 'الفرق', '🛡'], ['points', 'الترقيات والنقاط', '⭐'], ['ranks', 'الرتب والشارات', '🎖']];
  if (adm) items.push(['activity', 'سجل النشاطات', '📜']);
  $('#app').innerHTML = `<div class="shell"><aside class="side"><div class="brand"><img src="logo.svg" alt=""><div><b>LT POLICE</b><small>نظام إدارة الشرطة</small></div></div>
  <nav>${items.map(i => `<a href="#${i[0]}" data-p="${i[0]}"><i>${i[2]}</i>${i[1]}</a>`).join('')}</nav>
  <div class="me"><div class="av">${esc(me.full_name.trim().charAt(0))}</div><div class="mi"><b>${esc(me.full_name)}</b><small>${ROLE[me.role]}</small></div><div class="mact"><button class="btn ghost sm" id="pw">كلمة المرور</button><button class="btn ghost sm" id="lo">خروج</button></div></div></aside>
  <div class="content"><main id="main"></main></div></div>`;
  $('#pw').onclick = () => pwDialog(false); $('#lo').onclick = logout;
  window.onhashchange = route; route();
}
function route() {
  const p = location.hash.slice(1) || 'dashboard';
  const m = $('#main'); if (m) m.onclick = null; // منع تداخل أزرار الصفحات (مثل حذف ضابط يحذف فرقة)
  document.querySelectorAll('nav a').forEach(a => a.classList.toggle('on', a.dataset.p === p));
  const v = { dashboard, officers, teams, points, ranks: ranksView, activity }[p] || dashboard;
  v().catch(e => toast(e.message, 1));
}
const actTable = rows => `<div class="tw"><table><tr><th>الوقت</th><th>المنفذ</th><th>الإجراء</th><th>تفاصيل</th></tr>${rows.map(a => `<tr><td>${esc(fmtDate(a.created_at))}</td><td>${esc(a.user_name || '—')}</td><td>${esc(a.action)}</td><td>${esc(a.details)}</td></tr>`).join('')}</table></div>`;

// ---------- الصفحات ----------
async function dashboard() {
  const d = await api('/dashboard');
  const st = (l, n) => `<div class="stat"><b>${n}</b><span>${l}</span></div>`;
  $('#main').innerHTML = `<h2>لوحة التحكم</h2><div class="stats">${st('الضباط النشطون', d.officers)}${st('الفرق', d.teams)}${st('الفرق النشطة', d.active_teams)}${st('حسابات غير نشطة', d.suspended)}</div>${d.activity ? '<h3>آخر العمليات الإدارية</h3>' + actTable(d.activity) : ''}`;
}
async function activity() { $('#main').innerHTML = '<h2>سجل النشاطات</h2>' + actTable(await api('/activity')); }

const staffRole = () => ['sysadmin', 'senior'].includes(me.role);
async function awardDialog(o, done) {
  const acts = await api('/points/actions');
  formDialog('منح نقاط: ' + o.full_name, [{ k: 'action_id', label: 'العمل', type: 'select', options: [['', '— نقاط تقديرية (بأمر قائد) —'], ...acts.map(a => [a.id, `${a.category} · ${a.name} (${a.points})`])] }, { k: 'qty', label: 'العدد (عدد الساعات أو المرات)', type: 'number' }, { k: 'points', label: 'عدد النقاط (للتقديرية فقط، 1-500)', type: 'number' }, { k: 'note', label: 'ملاحظة / سبب', type: 'textarea' }],
    { qty: 1 }, async d => { await api('/records', { method: 'POST', body: { ...d, user_id: o.id } }); toast('تم منح النقاط'); done(); });
}
async function penaltyDialog(o, done) {
  const DEG = (await api('/rules')).degrees;
  formDialog('عقوبة: ' + o.full_name, [{ k: 'degree', label: 'درجة العقوبة', type: 'select', options: DEG.map(g => [g.degree, `الدرجة ${g.degree}: ${g.label}`]) }, { k: 'title', label: 'المخالفة', required: 1 }, { k: 'deduct', label: 'النقاط المخصومة (للدرجتين 2 و3)', type: 'number' }, { k: 'demote', label: 'عدد الرتب المنزّلة (للدرجة 4)', type: 'select', options: [[1, 'رتبة واحدة'], [2, 'رتبتان']] }, { k: 'note', label: 'ملاحظة', type: 'textarea' }],
    { degree: 2 }, async d => { await api('/penalties', { method: 'POST', body: { ...d, user_id: o.id } }); toast('تم تسجيل العقوبة'); done(); });
}
function dismissDialog(o, done) {
  formDialog('فصل: ' + o.full_name, [{ k: 'title', label: 'سبب الفصل', required: 1 }, { k: 'note', label: 'ملاحظة', type: 'textarea' }], {}, async d => {
    if (!confirm(`فصل ${o.full_name}؟ سيُوقف حسابه ويُسجَّل في سجله.`)) throw new Error('تم الإلغاء');
    await api('/penalties', { method: 'POST', body: { ...d, degree: 1, user_id: o.id } }); toast('تم الفصل'); done();
  });
}
async function promoteDo(o, done) {
  let force = false;
  if (!o.eligible) { if (me.role !== 'sysadmin') return toast('لم يبلغ النقاط المطلوبة للرتبة التالية', 1); if (!confirm('لم يبلغ النقاط المطلوبة. هل تريد ترقية استثنائية؟')) return; force = true; }
  else if (!confirm(`ترقية ${o.full_name} إلى ${o.next_name}؟`)) return;
  await api(`/officers/${o.id}/promote`, { method: 'POST', body: { force } }); toast('تمت الترقية'); done();
}
async function historyDialog(o) {
  const h = await api(`/officers/${o.id}/records`), T = { award: 'نقاط', penalty: 'عقوبة', promotion: 'ترقية' };
  infoDialog(`سجل ${o.full_name} (${h.points} نقطة)`, `<div class="tw"><table><tr><th>التاريخ</th><th>النوع</th><th>التفاصيل</th><th>النقاط</th></tr>${h.records.map(r => `<tr><td>${esc(fmtDate(r.created_at))}</td><td>${T[r.type]}${r.degree ? ' د' + r.degree : ''}</td><td style="white-space:normal">${esc(r.title)}${r.rank_to_name ? ` (${esc(r.rank_from_name || '—')} ← ${esc(r.rank_to_name)})` : ''}${r.note ? '<br><small>' + esc(r.note) + '</small>' : ''}</td><td dir="ltr">${r.delta > 0 ? '+' : ''}${r.delta || ''}</td></tr>`).join('') || '<tr><td colspan="4">لا يوجد سجل</td></tr>'}</table></div>`);
}

async function officers() {
  const [list, teams, sm] = await Promise.all([api('/officers'), api('/teams'), api('/points/summary')]);
  const P = Object.fromEntries(sm.map(x => [x.id, x]));
  const sa = me.role === 'sysadmin', st = staffRole();
  $('#main').innerHTML = `<div class="bar"><h2>الضباط</h2><input id="q" placeholder="بحث بالاسم أو الرقم العسكري">${sa ? '<button class="btn" id="add">+ ضابط</button>' : ''}</div><div class="ogrid" id="og"></div>`;
  const card = o => {
    const p = P[o.id], act = o.status === 'active';
    const pct = p && p.next_required ? Math.min(100, Math.round(p.points / p.next_required * 100)) : 0;
    return `<div class="ocard"><div class="oh">${badge(o.rank_badge, o.rank_level)}<div class="oi"><b>${esc(o.full_name)}</b><small>${esc(o.rank_name || '—')} · ${esc(o.military_no)}</small></div>${tag(o.status)}</div>
    <div class="om"><span>الفرقة: ${esc(o.team_name || '—')}</span><span>${esc(o.team_position || '—')}</span></div>
    ${p ? `<div><div class="pt"><span><b>${p.points}</b> نقطة</span><span>${p.next_name ? esc(p.next_name) + (p.next_required != null ? ' · ' + p.next_required : '') : 'أعلى رتبة'}${p.eligible ? ' <span class="tag active">مستحق</span>' : ''}</span></div>${p.next_required ? `<div class="pbar ${p.eligible ? 'ok' : ''}"><i style="width:${pct}%"></i></div>` : ''}</div>` : ''}
    ${st && act ? `<div class="oa">${p && p.next_name ? `<button class="btn ${p.eligible ? 'ok' : 'ghost'} sm" data-u="${o.id}">ترقية</button>` : ''}<button class="btn sm" data-a="${o.id}">+ نقاط</button><button class="btn ghost sm" data-p="${o.id}">عقوبة</button><button class="btn red sm" data-f="${o.id}">فصل</button></div>` : ''}
    <div class="oa sub">${st || o.id === me.id ? `<button class="btn ghost sm" data-h="${o.id}">السجل</button>` : ''}${sa ? `<button class="btn ghost sm" data-e="${o.id}">تعديل</button><button class="btn ghost sm" data-r="${o.id}">كلمة مرور</button><button class="btn ghost sm" data-d="${o.id}">حذف</button>` : ''}</div></div>`;
  };
  const draw = () => {
    const q = $('#q').value.trim();
    $('#og').innerHTML = list.filter(o => !q || o.full_name.includes(q) || o.military_no.includes(q)).map(card).join('') || '<p>لا توجد نتائج</p>';
  };
  $('#q').oninput = draw; draw();
  const fields = creating => [
    { k: 'full_name', label: 'الاسم الكامل', required: 1 }, ...(creating ? [{ k: 'username', label: 'اسم المستخدم (إنجليزي)', required: 1 }, { k: 'password', label: 'كلمة المرور المبدئية (8 أحرف+)', type: 'password', required: 1 }] : []),
    { k: 'military_no', label: 'الرقم العسكري', required: 1 },
    { k: 'rank_id', label: 'الرتبة', type: 'select', options: [['', '— بدون —'], ...ranks.map(r => [r.id, r.name])] },
    { k: 'role', label: 'الدور', type: 'select', options: Object.entries(ROLE) },
    { k: 'team_id', label: 'الفرقة', type: 'select', options: [['', '— بدون —'], ...teams.map(t => [t.id, t.name])] },
    { k: 'team_position', label: 'المنصب داخل الفرقة' }, { k: 'appointed_at', label: 'تاريخ التعيين', type: 'date' },
    { k: 'status', label: 'الحالة الوظيفية', type: 'select', options: Object.entries(STAT) }];
  if (sa) $('#add').onclick = () => formDialog('إضافة ضابط', fields(true), { role: 'officer', status: 'active' }, async d => { await api('/officers', { method: 'POST', body: d }); toast('تمت الإضافة'); officers(); });
  $('#og').onclick = async e => {
    const b = e.target.closest('button'); if (!b) return;
    const id = b.dataset.u || b.dataset.a || b.dataset.p || b.dataset.f || b.dataset.h || b.dataset.e || b.dataset.r || b.dataset.d;
    const o = list.find(x => x.id == id), x = { ...o, ...P[id] };
    try {
      if (b.dataset.u) await promoteDo(x, officers);
      if (b.dataset.a) await awardDialog(x, officers);
      if (b.dataset.p) await penaltyDialog(x, officers);
      if (b.dataset.f) dismissDialog(x, officers);
      if (b.dataset.h) await historyDialog(x);
      if (b.dataset.e) formDialog('تعديل: ' + o.full_name, fields(false), o, async d => { await api('/officers/' + o.id, { method: 'PUT', body: d }); toast('تم الحفظ'); officers(); });
      if (b.dataset.r) confirmDo('إنشاء كلمة مرور مؤقتة لهذا الضابط؟', async () => { const r = await api(`/officers/${o.id}/reset-password`, { method: 'POST' }); prompt('كلمة المرور المؤقتة (سلّمها للضابط، ستُطلب منه تغييرها):', r.temp_password); });
      if (b.dataset.d) confirmDo('حذف الضابط نهائياً؟', async () => { await api('/officers/' + o.id, { method: 'DELETE' }); toast('تم الحذف'); officers(); });
    } catch (er) { toast(er.message, 1); }
  };
}

async function teams() {
  const [list, offs] = await Promise.all([api('/teams'), api('/officers')]);
  const adm = me.role === 'sysadmin';
  $('#main').innerHTML = `<div class="bar"><h2>الفرق</h2>${adm ? '<button class="btn" id="add">+ فرقة جديدة</button>' : ''}</div><div class="grid">${list.map(t => `<div class="card"><div class="team-h">${t.logo ? `<img src="${esc(t.logo)}" alt="">` : '<div class="logo-ph">LT</div>'}<div><b>${esc(t.name)}</b><br>${tag(t.status)}</div></div>
    <p>القائد: ${esc(t.leader_name || '—')}<br>النائب: ${esc(t.deputy_name || '—')}<br>الأعضاء: ${t.members_count}</p><p style="color:var(--mute)">${esc(t.mission || '')}</p>
    <button class="btn ghost sm" data-m="${t.id}">الأعضاء</button>${adm ? ` <button class="btn sm" data-e="${t.id}">تعديل</button> <button class="btn ghost sm" data-s="${t.id}">${t.status === 'active' ? 'إيقاف' : 'تفعيل'}</button> <button class="btn red sm" data-d="${t.id}">حذف</button>` : ''}</div>`).join('') || '<p>لا توجد فرق بعد.</p>'}</div>`;
  const people = [['', '— بدون —'], ...offs.filter(o => o.status === 'active').map(o => [o.id, o.full_name])];
  const fields = [{ k: 'name', label: 'اسم الفرقة', required: 1 }, { k: 'logo', label: 'شعار الفرقة', type: 'image' }, { k: 'mission', label: 'المهام والاختصاصات', type: 'textarea' },
    { k: 'leader_id', label: 'قائد الفرقة', type: 'select', options: people }, { k: 'deputy_id', label: 'نائب القائد', type: 'select', options: people }];
  if (adm) $('#add').onclick = () => formDialog('إنشاء فرقة', fields, {}, async d => { await api('/teams', { method: 'POST', body: d }); toast('تم إنشاء الفرقة'); teams(); });
  $('#main').onclick = async e => {
    const b = e.target.closest('button[data-m],button[data-e],button[data-s],button[data-d]'); if (!b) return;
    const id = b.dataset.m || b.dataset.e || b.dataset.s || b.dataset.d, t = list.find(x => x.id == id);
    try {
      if (b.dataset.m) { const full = await api('/teams/' + id); membersDialog(full); }
      if (b.dataset.e) formDialog('تعديل فرقة', fields, t, async d => { await api('/teams/' + id, { method: 'PUT', body: d }); toast('تم الحفظ'); teams(); });
      if (b.dataset.s) { await api(`/teams/${id}/status`, { method: 'POST', body: { status: t.status === 'active' ? 'suspended' : 'active' } }); teams(); }
      if (b.dataset.d) confirmDo('حذف الفرقة؟ سيُفصل أعضاؤها عنها.', async () => { await api('/teams/' + id, { method: 'DELETE' }); teams(); });
    } catch (er) { toast(er.message, 1); }
  };
}

async function ranksView() {
  ranks = await api('/ranks');
  const adm = me.role === 'sysadmin';
  const row = r => `<div class="card rk">${badge(r.badge, r.level)}<div style="flex:1"><b>${esc(r.name)}</b><br><small style="color:var(--mute)">${r.category === 'officer' ? 'رتب الضباط' : 'رتب الأفراد'}${r.points_required != null ? ' · ' + r.points_required + ' نقطة' : ''}</small>${r.description ? `<br><small>${esc(r.description)}</small>` : ''}</div>${adm ? `<button class="btn ghost sm" data-k="${r.id}">متطلبات</button> <button class="btn sm" data-u="${r.id}">رفع شارة</button>${r.badge ? ` <button class="btn red sm" data-x="${r.id}">إزالة</button>` : ''}` : ''}</div>`;
  $('#main').innerHTML = `<h2>الرتب والشارات</h2><p style="color:var(--mute)">من الأدنى إلى الأعلى. ارفع صورة PNG شفافة لكل رتبة وستظهر في كل أجزاء النظام.</p><div class="grid">${ranks.map(row).join('')}</div>`;
  $('#main').onclick = e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.u) formDialog('رفع شارة الرتبة', [{ k: 'image', label: 'صورة الشارة (PNG/JPG/WebP)', type: 'image' }], {}, async d => { if (!d.image) throw new Error('اختر صورة'); await api(`/ranks/${b.dataset.u}/badge`, { method: 'PUT', body: d }); toast('تم رفع الشارة'); ranksView(); });
    if (b.dataset.k) { const r = ranks.find(x => x.id == b.dataset.k); formDialog('متطلبات: ' + r.name, [{ k: 'points_required', label: 'النقاط المطلوبة للوصول لهذه الرتبة (فارغ = غير محدد)', type: 'number' }, { k: 'description', label: 'الصلاحيات والوصف', type: 'textarea' }], r, async d => { await api('/ranks/' + r.id, { method: 'PUT', body: d }); toast('تم الحفظ'); ranksView(); }); }
    if (b.dataset.x) confirmDo('إزالة الشارة؟', async () => { await api(`/ranks/${b.dataset.x}/badge`, { method: 'DELETE' }); ranksView(); });
  };
}
// ---------- الترقيات والنقاط والعقوبات ----------
let ptab = 'elig';
const infoDialog = (title, html) => {
  const d = document.createElement('dialog');
  d.innerHTML = `<h3>${esc(title)}</h3>${html}<div class="row"><button class="btn ghost" data-x>إغلاق</button></div>`;
  document.body.appendChild(d); d.showModal(); d.addEventListener('close', () => d.remove()); d.querySelector('[data-x]').onclick = () => d.close();
};
async function points() {
  const adm = ['sysadmin', 'senior'].includes(me.role), sa = me.role === 'sysadmin';
  const tabs = [['elig', 'الاستحقاق والنقاط'], ['acts', 'جدول النقاط'], ['rules', 'القوانين والعقوبات']];
  $('#main').innerHTML = `<h2>الترقيات والنقاط</h2><div class="bar">${tabs.map(t => `<button class="btn ${t[0] === ptab ? '' : 'ghost'} sm" data-t="${t[0]}">${t[1]}</button>`).join('')}</div><div id="pb"></div>`;
  $('#main').onclick = e => { const b = e.target.closest('[data-t]'); if (b) { ptab = b.dataset.t; points().catch(er => toast(er.message, 1)); } };
  await ({ elig: pElig, acts: pActs, rules: pRules }[ptab])(adm, sa);
}
async function pElig(adm, sa) {
  const L = await api('/points/summary');
  $('#pb').innerHTML = `<div class="tw"><table><tr><th>الرتبة</th><th>الاسم</th><th>النقاط</th><th>الرتبة التالية</th><th>التقدم</th><th></th></tr>${L.map(o => `<tr><td>${badge(o.rank_badge, o.rank_level)}${esc(o.rank_name || '—')}</td><td>${esc(o.full_name)}</td><td><b>${o.points}</b></td><td>${esc(o.next_name || 'أعلى رتبة')}</td>
    <td>${o.next_name ? (o.next_required == null ? 'لم تُحدد النقاط' : `${o.points} / ${o.next_required} ${o.eligible ? '<span class="tag active">مستحق</span>' : ''}`) : '—'}</td>
    <td>${adm ? `<button class="btn sm" data-a="${o.id}">+ نقاط</button> <button class="btn ghost sm" data-p="${o.id}">عقوبة</button> ${o.next_name ? `<button class="btn sm" data-u="${o.id}">ترقية</button> ` : ''}<button class="btn red sm" data-f="${o.id}">فصل</button> ` : ''}${adm || o.id === me.id ? `<button class="btn ghost sm" data-h="${o.id}">السجل</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="6">لا يوجد ضباط</td></tr>'}</table></div>`;
  const again = () => pElig(adm, sa);
  $('#pb').onclick = async e => {
    const b = e.target.closest('button'); if (!b) return;
    const o = L.find(x => x.id == (b.dataset.a || b.dataset.p || b.dataset.u || b.dataset.f || b.dataset.h));
    try {
      if (b.dataset.a) await awardDialog(o, again);
      if (b.dataset.p) await penaltyDialog(o, again);
      if (b.dataset.f) dismissDialog(o, again);
      if (b.dataset.u) await promoteDo(o, again);
      if (b.dataset.h) await historyDialog(o);
    } catch (er) { toast(er.message, 1); }
  };
}
async function pActs(adm, sa) {
  const A = await api('/points/actions'), cats = [...new Set(A.map(a => a.category))];
  const fields = [{ k: 'category', label: 'التصنيف (مثل: سرقات، داخلية)', required: 1 }, { k: 'name', label: 'العمل', required: 1 }, { k: 'points', label: 'النقاط', type: 'number', required: 1 }, { k: 'note', label: 'الشرح' }];
  $('#pb').innerHTML = (sa ? '<div class="bar"><span style="flex:1"></span><button class="btn" id="add">+ عمل جديد</button></div>' : '') + (cats.map(c => `<h3>${esc(c)}</h3><div class="tw"><table><tr><th>العمل</th><th>النقاط</th><th>الشرح</th>${sa ? '<th></th>' : ''}</tr>${A.filter(a => a.category === c).map(a => `<tr><td>${esc(a.name)}</td><td><b>${a.points}</b></td><td style="white-space:normal">${esc(a.note || '')}</td>${sa ? `<td><button class="btn sm" data-e="${a.id}">تعديل</button> <button class="btn red sm" data-d="${a.id}">حذف</button></td>` : ''}</tr>`).join('')}</table></div>`).join('') || '<p>لا توجد أعمال.</p>') + '<p style="color:var(--mute)">النقاط التقديرية (زيادة نقاط أو ترقية) تُمنح بأمر قائد حسب التقرير.</p>';
  if (!sa) return;
  $('#add').onclick = () => formDialog('إضافة عمل', fields, {}, async d => { await api('/points/actions', { method: 'POST', body: d }); toast('تمت الإضافة'); pActs(adm, sa); });
  $('#pb').onclick = e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.e) { const a = A.find(x => x.id == b.dataset.e); formDialog('تعديل عمل', fields, a, async d => { await api('/points/actions/' + a.id, { method: 'PUT', body: d }); toast('تم الحفظ'); pActs(adm, sa); }); }
    if (b.dataset.d) confirmDo('حذف هذا العمل؟', async () => { await api('/points/actions/' + b.dataset.d, { method: 'DELETE' }); pActs(adm, sa); });
  };
}
async function pRules(adm, sa) {
  const R = await api('/rules'), del = id => sa ? ` <button class="btn red sm" data-d="${id}">×</button>` : '';
  $('#pb').innerHTML = (sa ? '<div class="bar"><span style="flex:1"></span><button class="btn" id="add">+ قانون / بند</button></div>' : '') +
    `<div class="card"><h3>القوانين العسكرية</h3><ol>${R.laws.map(l => `<li>${esc(l.text)}${del(l.id)}</li>`).join('')}</ol><p style="color:var(--danger)">جميع القوانين إذا لم يتم العمل بها يتم فصلك مباشرة.</p></div><h3>درجات المخالفات والعقوبات</h3><div class="grid">${R.degrees.map(g => `<div class="card"><b>الدرجة ${g.degree}</b><br><span class="tag suspended">${esc(g.label)}</span><ul>${g.items.map(i => `<li>${esc(i.text)}${del(i.id)}</li>`).join('') || '<li>—</li>'}</ul></div>`).join('')}</div>`;
  if (!sa) return;
  $('#add').onclick = () => formDialog('إضافة قانون أو بند', [{ k: 'kind', label: 'النوع', type: 'select', options: [['violation', 'بند مخالفة'], ['law', 'قانون عسكري']] }, { k: 'degree', label: 'الدرجة (للبنود فقط)', type: 'select', options: R.degrees.map(g => [g.degree, 'الدرجة ' + g.degree]) }, { k: 'text', label: 'النص', required: 1 }], { kind: 'violation', degree: 1 }, async d => { await api('/rules', { method: 'POST', body: d }); toast('تمت الإضافة'); pRules(adm, sa); });
  $('#pb').onclick = e => { const b = e.target.closest('button[data-d]'); if (b) confirmDo('حذف؟', async () => { await api('/rules/' + b.dataset.d, { method: 'DELETE' }); pRules(adm, sa); }); };
}
boot();
